# Healthy PC Monitoring & IT Asset Management

A production-oriented starting project for a Head Office-hosted IT operations portal. It includes a React dashboard, FastAPI backend, PostgreSQL schema, Windows Exporter/Prometheus integration points, CrowdStrike Falcon OAuth2 host inventory integration, branch and asset CRUD, stock movement records, role-aware user management and audit logs.

> This is an installable application foundation, not a claim that your endpoints or Falcon tenant are already connected. Live readings require Windows Exporter deployment, network reachability and Prometheus target configuration. Falcon data requires valid API credentials and scopes. Review the security checklist before production use.

## Requirements

- Head Office Windows Server or Linux server with Docker Engine + Docker Compose plugin.
- Static/private IP or DNS name; HTTPS reverse proxy and company DNS recommended.
- Network routes/VPN from monitoring gateway to branch endpoints.
- CrowdStrike Falcon API client credentials and correct regional API base URL.

## Quick start (Head Office server)

1. Copy this project folder to the server.
2. Create environment file:

   ```bash
   cp .env.example .env
   ```

   On Windows PowerShell: `Copy-Item .env.example .env`
3. Edit `.env`. Generate strong secrets (PowerShell example):

   ```powershell
   [Convert]::ToBase64String([Security.Cryptography.RandomNumberGenerator]::GetBytes(48))
   ```

   Use separate random values for `POSTGRES_PASSWORD` and `JWT_SECRET`. Keep `DATABASE_URL` credentials synchronized with the PostgreSQL username/password; URL-encode reserved characters in the password. Set a unique `ADMIN_PASSWORD` with at least 12 characters. Keep `.env` private and out of source control.
4. Start core services:

   ```bash
   docker compose up -d --build
   ```

   Windows PowerShell uses the same command if Docker Desktop/Engine is installed.
5. Open `http://<head-office-server>:8080`. Sign in using `ADMIN_EMAIL` and `ADMIN_PASSWORD` from `.env`.
6. Immediately change the bootstrap admin password through your operational process; create named admin accounts; then set `BOOTSTRAP_ADMIN=false` and restart the API (`docker compose up -d --force-recreate api`).
7. Create or update branch records and register real assets. The initial database seeds Head Office and 16 generic branch placeholders (BR-01…BR-16); rename these to the actual branch names.

## Start monitoring services

```bash
docker compose --profile monitoring up -d
```

Edit `monitoring/prometheus.yml` and replace the example `host.docker.internal:9182` with reachable Windows Exporter targets or a gateway target. See `docs/INSTALL-WINDOWS.md`. Prometheus is bound to localhost on port 9090 by default; do not expose it publicly. The web UI/API reads scrape target status and uses allowlisted PromQL queries.

For 16 branches, recommended topology is Head Office Prometheus + branch VPN connectivity, or one collector per branch forwarding to the central monitoring layer. Configure site-specific targets and `location` labels. For large fleets, use Prometheus federation/remote-write or a supported agent architecture and size retention/storage accordingly.

## CrowdStrike Falcon

1. Create an API client in the Falcon console with the minimum read scopes needed for host/device inventory (typically Hosts: Read; verify exact scope names in your Falcon tenant documentation).
2. Set `CROWDSTRIKE_ENABLED=true`, `CROWDSTRIKE_BASE_URL` to the correct regional Falcon API host, plus `CROWDSTRIKE_CLIENT_ID` and `CROWDSTRIKE_CLIENT_SECRET` in the server `.env`.
3. Restart API: `docker compose up -d --force-recreate api`.
4. Sign in as Super Admin, IT Manager or IT Support and open CrowdStrike → Fetch Falcon hosts.
5. Credentials are backend-only; never place them in React, browser storage, a public repo or a client-side environment variable. Rotate/revoke credentials if exposed.

Falcon API endpoint availability and returned fields depend on your tenant, region, subscription and API scopes. This integration currently retrieves host inventory; it does not run containment or Real Time Response actions.

## Roles

- Super Admin: full user, branch, asset and audit administration.
- IT Manager: manage branches, users, assets and operational visibility.
- IT Support: manage assets and stock movements; read monitoring and Falcon hosts.
- Branch Admin: branch-scoped asset registration/editing.
- Viewer: authenticated read-only access.

This starter implements password authentication and role checks. MFA is not implemented in-app. Before internet-facing production, integrate your corporate IdP (OIDC/SAML) or enforce MFA at a trusted identity-aware reverse proxy. Add approval workflows and formal user invitation/password-reset delivery before broad rollout.

## Database and backups

PostgreSQL tables: `branches`, `users`, `assets`, `stock_movements`, `telemetry`, `audit_logs`. Database migrations are not yet configured; schema is created at API startup for this initial release. Before upgrades, introduce Alembic migrations and test restore procedures.

Example backup:

```bash
docker compose exec -T db pg_dump -U healthy_pc healthy_pc > healthy_pc_backup.sql
```

Protect backups with encryption and off-host retention. Test restore regularly.

## Production security checklist

- Put the app behind HTTPS (IIS ARR, Nginx, Caddy or corporate reverse proxy); do not expose API, database or Prometheus directly to the internet.
- Set `CORS_ORIGIN` to the exact trusted UI origin if cross-origin access is required. Leave blank for same-origin deployment.
- Change all default/placeholder secrets; protect `.env` with OS ACLs; rotate credentials periodically.
- Restrict server firewall: expose only HTTPS/UI to authorized networks; PostgreSQL stays on Docker internal network; Prometheus stays private.
- Use MFA/SSO, least-privilege Falcon scopes, admin access restrictions, TLS, backups, patching, central log retention and incident response procedures.
- Set alert thresholds and offline windows to match company policy. Current summary counts latest telemetry records only; configure a production telemetry ingestion pipeline/recording rules before using endpoint counts as an SLA.
- Validate branch-level authorization and asset movement approvals against your internal policy before go-live.

## API overview

- `POST /api/auth/token` – OAuth2 password login (form fields `username`, `password`)
- `GET /api/auth/me`
- `GET/POST /api/branches`; `PATCH /api/branches/{id}`
- `GET/POST /api/assets`; `PATCH /api/assets/{id}`
- `POST /api/assets/{id}/movements`
- `GET/POST /api/users`; `PATCH /api/users/{id}`
- `GET /api/dashboard/summary`
- `GET /api/monitoring/targets`
- `GET /api/monitoring/prometheus/query?q=cpu|memory|disk`
- `GET /api/security/crowdstrike/hosts`
- `GET /api/audit`
- `GET /api/docs` – interactive API docs (restrict in production)

## Troubleshooting

```bash
docker compose ps
docker compose logs -f api
docker compose logs -f web
docker compose logs -f db
```

If the browser cannot load the site, check port 8080 and server firewall. If login fails, check the bootstrap values and API logs. If Prometheus targets are down, verify exporter service, DNS/routing, port 9182 firewall and target address from the Prometheus container. If Falcon returns 401/403, verify regional base URL, API client secret and host read scopes.

## Known implementation boundaries

- Metrics collection depends on Prometheus scraping; the UI intentionally does not fabricate CPU/RAM/SSD values.
- Telemetry schema is prepared but a fleet-wide ingest/normalization worker and time-series retention strategy should be completed before production SLA reporting.
- The current Falcon connector reads host inventory only. Detection/event ingestion and alert correlation can be added with approved API scopes.
- No email invitation, password reset mailer, MFA/SSO or immutable external audit sink is included in this starter.
- For high availability and large endpoint counts, add a load balancer, managed PostgreSQL/HA, Prometheus federation/remote-write, migrations, observability and disaster recovery.
