import httpx
from .config import settings

async def prometheus_query(query: str):
    if not settings.prometheus_enabled: return None
    async with httpx.AsyncClient(timeout=8) as client:
        response = await client.get(f"{settings.prometheus_url}/api/v1/query", params={"query": query})
        response.raise_for_status()
        payload = response.json()
        if payload.get("status") != "success": raise RuntimeError("Prometheus query failed")
        return payload.get("data", {}).get("result", [])

async def crowdstrike_hosts():
    if not settings.crowdstrike_enabled or not settings.crowdstrike_client_id or not settings.crowdstrike_client_secret:
        return {"configured": False, "hosts": [], "message": "CrowdStrike API is not configured. Add Falcon API credentials to the server .env file."}
    async with httpx.AsyncClient(timeout=15) as client:
        token = await client.post(f"{settings.crowdstrike_base_url}/oauth2/token", data={"client_id":settings.crowdstrike_client_id,"client_secret":settings.crowdstrike_client_secret})
        token.raise_for_status()
        access_token = token.json()["access_token"]
        headers = {"Authorization":f"Bearer {access_token}"}
        ids_response = await client.get(f"{settings.crowdstrike_base_url}/devices/queries/devices/v1", headers=headers, params={"limit":100})
        ids_response.raise_for_status()
        ids = ids_response.json().get("resources", [])
        if not ids: return {"configured": True, "hosts": []}
        details = await client.get(f"{settings.crowdstrike_base_url}/devices/entities/devices/v2", headers=headers, params=[("ids", item) for item in ids])
        details.raise_for_status()
        return {"configured":True,"hosts":details.json().get("resources",[])}
