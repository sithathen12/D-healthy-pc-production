# Windows endpoint setup

1. Install the official Prometheus Community Windows Exporter on each managed Windows endpoint. Use the official MSI release from https://github.com/prometheus-community/windows_exporter/releases.
2. Enable only the collectors needed (cpu, memory, logical_disk, os, system, cs). Keep exporter version consistent and patch it regularly.
3. Restrict TCP/9182 inbound to the Head Office monitoring gateway IP only. Do not expose this port to the public internet.
4. Ensure the Head Office gateway can resolve/reach each endpoint. For remote branches, use site-to-site VPN or a branch-local Prometheus/agent gateway; do not publish exporter ports publicly.
5. Add the endpoint or gateway targets to `monitoring/prometheus.yml`, including a `location` label. Restart/reload Prometheus.
6. Confirm target health in Prometheus `http://<head-office-server>:9090/targets` (keep port 9090 bound to localhost or protected admin network).

Example Windows Firewall rule (run elevated, replace the IP):

```powershell
New-NetFirewallRule -DisplayName "Windows Exporter from Head Office" -Direction Inbound -Protocol TCP -LocalPort 9182 -RemoteAddress 10.0.0.10 -Action Allow
```

Do not install the exporter with an unrestricted firewall rule. Exporter metrics can reveal host and infrastructure details.
