from datetime import datetime, timezone, timedelta
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session
from sqlalchemy import desc, func
from .config import settings
from .db import Base, engine, get_db, SessionLocal
from .models import Branch, User, Asset, StockMovement, Telemetry, AuditLog
from .security import hash_password, verify_password, create_token, current_user, require_roles
from .integrations import prometheus_query, crowdstrike_hosts

Base.metadata.create_all(bind=engine)
app = FastAPI(title="Healthy PC Management API", version="1.0.0", docs_url="/api/docs")
if settings.cors_origin:
    app.add_middleware(CORSMiddleware, allow_origins=[x.strip() for x in settings.cors_origin.split(",") if x.strip()], allow_credentials=True, allow_methods=["GET","POST","PUT","PATCH","DELETE"], allow_headers=["Authorization","Content-Type"])

class BranchIn(BaseModel): code:str; name:str; address:str|None=None; is_head_office:bool=False
class UserIn(BaseModel): email:EmailStr; full_name:str; password:str=Field(min_length=12); role:str="Viewer"; branch_id:int|None=None
class AssetIn(BaseModel): asset_tag:str; serial_number:str|None=None; category:str="Laptop"; manufacturer:str="Unspecified"; model:str; branch_id:int; assigned_to:str|None=None; status:str="In stock"; cpu:str|None=None; ram_gb:int|None=None; storage_gb:int|None=None; purchase_date:str|None=None; warranty_until:str|None=None; notes:str|None=None
class MovementIn(BaseModel): movement_type:str; to_branch_id:int|None=None; reference:str|None=None

def audit(db,user,action,entity,entity_id=None,details=None,request=None):
    db.add(AuditLog(user_id=user.id if user else None, action=action, entity=entity, entity_id=str(entity_id) if entity_id else None, details=details, source_ip=request.client.host if request and request.client else None)); db.commit()

def branch_dict(b): return {"id":b.id,"code":b.code,"name":b.name,"address":b.address,"is_head_office":b.is_head_office,"is_active":b.is_active}
def asset_dict(a): return {"id":a.id,"asset_tag":a.asset_tag,"serial_number":a.serial_number,"category":a.category,"manufacturer":a.manufacturer,"model":a.model,"branch_id":a.branch_id,"branch":a.branch.name if a.branch else None,"assigned_to":a.assigned_to,"status":a.status,"cpu":a.cpu,"ram_gb":a.ram_gb,"storage_gb":a.storage_gb,"purchase_date":a.purchase_date,"warranty_until":a.warranty_until,"notes":a.notes}
def user_dict(u): return {"id":u.id,"email":u.email,"full_name":u.full_name,"role":u.role,"branch_id":u.branch_id,"is_active":u.is_active,"mfa_required":u.mfa_required}

@app.on_event("startup")
def bootstrap():
    db=SessionLocal()
    try:
        if db.query(Branch).count()==0:
            db.add(Branch(code="HQ",name="Head Office",is_head_office=True))
            for n in range(1,17): db.add(Branch(code=f"BR-{n:02d}",name=f"Branch {n:02d}"))
            db.commit()
        if settings.bootstrap_admin and not db.query(User).filter(User.email==settings.admin_email).first():
            hq=db.query(Branch).filter(Branch.is_head_office.is_(True)).first()
            db.add(User(email=settings.admin_email,full_name="System Administrator",password_hash=hash_password(settings.admin_password),role="Super Admin",branch_id=hq.id if hq else None)); db.commit()
    finally: db.close()

@app.get("/health")
def health(): return {"status":"ok","service":"healthy-pc-api"}
@app.post("/api/auth/token")
def login(form:OAuth2PasswordRequestForm=Depends(),db:Session=Depends(get_db)):
    user=db.query(User).filter(User.email==form.username.lower()).first()
    if not user or not user.is_active or not verify_password(form.password,user.password_hash): raise HTTPException(401,"Incorrect email or password")
    return {"access_token":create_token(user),"token_type":"bearer","user":user_dict(user)}
@app.get("/api/auth/me")
def me(user:User=Depends(current_user)): return user_dict(user)

@app.get("/api/branches")
def branches(db:Session=Depends(get_db),user:User=Depends(current_user)):
    rows=db.query(Branch).filter(Branch.is_active.is_(True)).order_by(Branch.id).all(); return [branch_dict(x) for x in rows]
@app.post("/api/branches")
def add_branch(data:BranchIn,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("Super Admin","IT Manager"))):
    if db.query(Branch).filter(Branch.code==data.code).first(): raise HTTPException(409,"Branch code already exists")
    b=Branch(**data.model_dump()); db.add(b); db.commit(); db.refresh(b); audit(db,user,"CREATE","branch",b.id,b.code,request); return branch_dict(b)
@app.patch("/api/branches/{branch_id}")
def update_branch(branch_id:int,data:dict,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("Super Admin","IT Manager"))):
    b=db.get(Branch,branch_id)
    if not b: raise HTTPException(404,"Branch not found")
    for k in ("name","address","is_active"):
        if k in data: setattr(b,k,data[k])
    db.commit(); audit(db,user,"UPDATE","branch",b.id,str(data),request); return branch_dict(b)

@app.get("/api/users")
def users(db:Session=Depends(get_db),user:User=Depends(require_roles("Super Admin","IT Manager"))): return [user_dict(u) for u in db.query(User).order_by(User.id).all()]
@app.post("/api/users")
def add_user(data:UserIn,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("Super Admin","IT Manager"))):
    if data.role not in ["Super Admin","IT Manager","IT Support","Branch Admin","Viewer"]: raise HTTPException(400,"Unsupported role")
    if db.query(User).filter(User.email==data.email).first(): raise HTTPException(409,"Email already exists")
    if data.branch_id and not db.get(Branch,data.branch_id): raise HTTPException(400,"Branch not found")
    u=User(email=data.email.lower(),full_name=data.full_name,password_hash=hash_password(data.password),role=data.role,branch_id=data.branch_id); db.add(u); db.commit(); db.refresh(u); audit(db,user,"CREATE","user",u.id,u.email,request); return user_dict(u)
@app.patch("/api/users/{user_id}")
def update_user(user_id:int,data:dict,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("Super Admin"))):
    u=db.get(User,user_id)
    if not u: raise HTTPException(404,"User not found")
    for k in ("full_name","role","branch_id","is_active","mfa_required"):
        if k in data: setattr(u,k,data[k])
    if data.get("password"): u.password_hash=hash_password(data["password"])
    db.commit(); audit(db,user,"UPDATE","user",u.id,"User settings changed",request); return user_dict(u)

@app.get("/api/assets")
def assets(db:Session=Depends(get_db),user:User=Depends(current_user)):
    q=db.query(Asset)
    if user.role=="Branch Admin" and user.branch_id: q=q.filter(Asset.branch_id==user.branch_id)
    return [asset_dict(a) for a in q.order_by(desc(Asset.id)).all()]
@app.post("/api/assets")
def add_asset(data:AssetIn,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("Super Admin","IT Manager","IT Support","Branch Admin"))):
    if db.query(Asset).filter(Asset.asset_tag==data.asset_tag).first(): raise HTTPException(409,"Asset tag already exists")
    if user.role=="Branch Admin" and data.branch_id!=user.branch_id: raise HTTPException(403,"Cannot add assets to another branch")
    if not db.get(Branch,data.branch_id): raise HTTPException(400,"Branch not found")
    a=Asset(**data.model_dump()); db.add(a); db.commit(); db.refresh(a); audit(db,user,"CREATE","asset",a.id,a.asset_tag,request); return asset_dict(a)
@app.patch("/api/assets/{asset_id}")
def update_asset(asset_id:int,data:dict,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("Super Admin","IT Manager","IT Support","Branch Admin"))):
    a=db.get(Asset,asset_id)
    if not a: raise HTTPException(404,"Asset not found")
    if user.role=="Branch Admin" and a.branch_id!=user.branch_id: raise HTTPException(403,"Cannot edit another branch")
    allowed={"serial_number","category","manufacturer","model","branch_id","assigned_to","status","cpu","ram_gb","storage_gb","purchase_date","warranty_until","notes"}
    for k,v in data.items():
        if user.role=="Branch Admin" and k=="branch_id" and v!=user.branch_id: raise HTTPException(403,"Cannot move assets to another branch")
        if k in allowed: setattr(a,k,v)
    db.commit(); audit(db,user,"UPDATE","asset",a.id,str(data),request); return asset_dict(a)
@app.post("/api/assets/{asset_id}/movements")
def move_asset(asset_id:int,data:MovementIn,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("Super Admin","IT Manager","IT Support"))):
    a=db.get(Asset,asset_id)
    if not a: raise HTTPException(404,"Asset not found")
    if data.movement_type not in ["RECEIVE","ISSUE","TRANSFER","RETURN","REPAIR","WRITE_OFF"]: raise HTTPException(400,"Invalid movement type")
    old=a.branch_id
    if data.movement_type=="TRANSFER":
        if not data.to_branch_id or not db.get(Branch,data.to_branch_id): raise HTTPException(400,"Valid destination branch required")
        a.branch_id=data.to_branch_id
    a.status={"RECEIVE":"In stock","ISSUE":"Assigned","RETURN":"In stock","REPAIR":"Repair","WRITE_OFF":"Written off","TRANSFER":a.status}[data.movement_type]
    db.add(StockMovement(asset_id=a.id,movement_type=data.movement_type,from_branch_id=old,to_branch_id=a.branch_id,performed_by=user.id,reference=data.reference)); db.commit(); audit(db,user,data.movement_type,"asset",a.id,data.reference,request); return asset_dict(a)

@app.get("/api/dashboard/summary")
async def summary(db:Session=Depends(get_db),user:User=Depends(current_user)):
    total=db.query(Asset).count(); stock=db.query(Asset).filter(Asset.status=="In stock").count(); branches_count=db.query(Branch).filter(Branch.is_active.is_(True)).count()
    latest=db.query(Telemetry).order_by(desc(Telemetry.observed_at)).limit(1000).all()
    cutoff=datetime.now(timezone.utc)-timedelta(minutes=5)
    seen={}
    for t in latest:
        if t.hostname not in seen: seen[t.hostname]=t
    online=sum(1 for t in seen.values() if t.observed_at and t.observed_at>=cutoff and t.online)
    monitored=len(seen)
    if settings.prometheus_enabled:
        try:
            import httpx
            async with httpx.AsyncClient(timeout=5) as client:
                response=await client.get(f"{settings.prometheus_url}/api/v1/targets"); response.raise_for_status()
                scrape_targets=response.json().get("data",{}).get("activeTargets",[])
                if scrape_targets:
                    monitored=len(scrape_targets); online=sum(1 for t in scrape_targets if t.get("health")=="up")
        except Exception: pass
    return {"assets_total":total,"assets_in_stock":stock,"branches":branches_count,"monitored_devices":monitored,"online":online,"offline":max(0,monitored-online),"telemetry_configured":settings.prometheus_enabled,"crowdstrike_configured":bool(settings.crowdstrike_enabled and settings.crowdstrike_client_id and settings.crowdstrike_client_secret)}
@app.get("/api/monitoring/targets")
async def targets():
    if not settings.prometheus_enabled: return {"configured":False,"targets":[]}
    try:
        import httpx
        async with httpx.AsyncClient(timeout=8) as c:
            r=await c.get(f"{settings.prometheus_url}/api/v1/targets"); r.raise_for_status(); data=r.json().get("data",{}).get("activeTargets",[])
        return {"configured":True,"targets":[{"instance":t.get("labels",{}).get("instance"),"job":t.get("labels",{}).get("job"),"health":t.get("health"),"last_scrape":t.get("lastScrape"),"error":t.get("lastError")} for t in data]}
    except Exception as e: return {"configured":True,"error":str(e),"targets":[]}
@app.get("/api/security/crowdstrike/hosts")
async def falcon_hosts(user:User=Depends(require_roles("Super Admin","IT Manager","IT Support"))):
    try: return await crowdstrike_hosts()
    except Exception as e: raise HTTPException(502,f"CrowdStrike API request failed: {str(e)}")
@app.get("/api/audit")
def audit_logs(db:Session=Depends(get_db),user:User=Depends(require_roles("Super Admin","IT Manager"))):
    return [{"id":x.id,"user_id":x.user_id,"action":x.action,"entity":x.entity,"entity_id":x.entity_id,"details":x.details,"source_ip":x.source_ip,"created_at":x.created_at} for x in db.query(AuditLog).order_by(desc(AuditLog.created_at)).limit(500).all()]
@app.get("/api/monitoring/prometheus/query")
async def query_metric(q:str,user:User=Depends(current_user)):
    # Allowlist only; do not expose arbitrary Prometheus queries to browsers.
    allowed={"cpu":"100 - (avg by (instance) (rate(windows_cpu_time_total{mode=\"idle\"}[5m])) * 100)","memory":"100 * (1 - windows_os_physical_memory_free_bytes / windows_cs_physical_memory_bytes)","disk":"100 * (1 - windows_logical_disk_free_bytes / windows_logical_disk_size_bytes)"}
    if q not in allowed: raise HTTPException(400,"Unsupported metric")
    try: return {"metric":q,"results":await prometheus_query(allowed[q])}
    except Exception as e: raise HTTPException(502,f"Monitoring query failed: {str(e)}")
