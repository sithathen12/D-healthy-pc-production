from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str = "postgresql+psycopg://healthy_pc:change-me@db:5432/healthy_pc"
    jwt_secret: str = "replace-this-secret-before-deployment"
    admin_email: str = "admin@company.local"
    admin_password: str = "ChangeThisAdminPassword123!"
    bootstrap_admin: bool = True
    cors_origin: str = ""
    prometheus_url: str = "http://prometheus:9090"
    prometheus_enabled: bool = True
    crowdstrike_base_url: str = "https://api.crowdstrike.com"
    crowdstrike_client_id: str = ""
    crowdstrike_client_secret: str = ""
    crowdstrike_enabled: bool = False
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
